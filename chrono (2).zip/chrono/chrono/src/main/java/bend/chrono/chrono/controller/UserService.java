/*package bend.chrono.chrono.controller;

import bend.chrono.chrono.model.User;
import bend.chrono.chrono.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
}
*/
package bend.chrono.chrono.controller;

import bend.chrono.chrono.model.User;
import bend.chrono.chrono.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Method to validate login credentials
    public boolean validateCredentials(String email, String password) {
        Optional<User> userOptional = Optional.empty();  // Assuming you have an email field in User

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            // For demonstration, comparing passwords directly (do NOT do this in production)
            return user.getPassword().equals(password);
        }
        return false; // Return false if user is not found
    }
}
