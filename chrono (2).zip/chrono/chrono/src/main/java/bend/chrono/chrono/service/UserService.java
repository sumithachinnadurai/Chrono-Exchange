package bend.chrono.chrono.service;

import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bend.chrono.chrono.model.Otp;
import bend.chrono.chrono.repository.OtpRepository;
import bend.chrono.chrono.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private OtpRepository otpRepository; // Repository for the OTP table

    private static final int OTP_LENGTH = 6;
    private static final int OTP_EXPIRATION_MINUTES = 5;

    public String generateOTP() {
        Random random = new SecureRandom();
        int otp = 100000 + random.nextInt(900000); // Generate a 6-digit OTP
        return String.valueOf(otp);
    }

    public void sendOtpToUser(String email) {
        String otp = generateOTP();
        Timestamp expirationTime = new Timestamp(System.currentTimeMillis() + OTP_EXPIRATION_MINUTES * 60 * 1000);

        // Save OTP to the database
        Otp otpEntity = new Otp();
        otpEntity.setEmail(email);
        otpEntity.setOtpCode(otp);
        otpEntity.setExpiration(expirationTime);
        otpRepository.save(otpEntity);

        // Send OTP via email (for example, using JavaMailSender)
        sendOtpEmail(email, otp);
    }

    private void sendOtpEmail(String email, String otp) {
        // Add JavaMailSender configuration here to send email with OTP
        System.out.println("Sending OTP " + otp + " to " + email);
        // Implement actual email sending logic here
    }

    public Object findByUsername(String username) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByUsername'");
    }
}
