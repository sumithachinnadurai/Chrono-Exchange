package bend.chrono.chrono;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChronoApplicationTests {

	@Test
	void contextLoads() {
	}

}
